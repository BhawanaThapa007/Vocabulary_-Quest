import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProgressSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/modules", async (_req, res) => {
    try {
      const modules = await storage.getAllModules();
      res.json(modules);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch modules" });
    }
  });

  app.get("/api/modules/:id", async (req, res) => {
    try {
      const module = await storage.getModuleById(req.params.id);
      if (!module) {
        return res.status(404).json({ error: "Module not found" });
      }
      res.json(module);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch module" });
    }
  });

  app.get("/api/modules/:id/sessions", async (req, res) => {
    try {
      const sessions = await storage.getSessionsByModuleId(req.params.id);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.get("/api/sessions/:id", async (req, res) => {
    try {
      const session = await storage.getSessionById(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch session" });
    }
  });

  app.get("/api/progress/:studentId", async (req, res) => {
    try {
      const studentId = req.params.studentId === "current-student" ? "demo-student" : req.params.studentId;
      const progress = await storage.getProgressByStudent(studentId);
      
      const completedSessionIds = progress
        .filter((p) => p.completed)
        .map((p) => p.sessionId);
      
      const completedSessions = completedSessionIds.length;
      const totalStars = progress.reduce((sum, p) => sum + (p.score || 0) / 20, 0);
      
      const modules = await storage.getAllModules();
      const allSessions = await storage.getAllSessions();
      
      const moduleProgress: Record<string, number> = {};
      for (const module of modules) {
        const moduleSessions = allSessions.filter((s) => s.moduleId === module.id);
        const completedModuleSessions = moduleSessions.filter((s) =>
          completedSessionIds.includes(s.id)
        );
        moduleProgress[module.id] = Math.round(
          (completedModuleSessions.length / moduleSessions.length) * 100
        );
      }

      const completedModules = modules
        .filter((m) => moduleProgress[m.id] === 100)
        .map((m) => m.order);

      res.json({
        progress,
        completedSessions,
        totalStars: Math.round(totalStars),
        moduleProgress,
        completedModules,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch progress" });
    }
  });

  app.post("/api/progress/complete", async (req, res) => {
    try {
      const validatedData = insertProgressSchema.parse({
        studentId: "demo-student",
        sessionId: req.body.sessionId,
        completed: true,
        score: req.body.score,
      });

      const studentId = validatedData.studentId;
      const existingProgress = await storage.getProgressByStudent(studentId);
      const existing = existingProgress.find((p) => p.sessionId === validatedData.sessionId);

      let progress;
      if (existing) {
        progress = await storage.updateProgress(existing.id, validatedData.score || 0, true);
      } else {
        progress = await storage.createProgress(validatedData);
      }

      const allProgress = await storage.getProgressByStudent(studentId);
      const completedCount = allProgress.filter((p) => p.completed).length;
      const totalScore = allProgress.reduce((sum, p) => sum + (p.score || 0), 0);

      await storage.getOrCreateLeaderboardEntry(studentId);
      const updatedLeaderboard = await storage.updateLeaderboardEntry(studentId, totalScore, completedCount);

      const studentAchievements = await storage.getStudentAchievements(studentId);
      const unlockedAchievementIds = new Set(studentAchievements.map(a => a.achievementId));

      if (completedCount === 1 && !unlockedAchievementIds.has("achievement-1")) {
        await storage.createStudentAchievement({
          studentId,
          achievementId: "achievement-1",
        });
      }

      if (validatedData.score === 100 && !unlockedAchievementIds.has("achievement-3")) {
        await storage.createStudentAchievement({
          studentId,
          achievementId: "achievement-3",
        });
      }

      const session = await storage.getSessionById(validatedData.sessionId);
      if (session) {
        const moduleSessions = await storage.getSessionsByModuleId(session.moduleId);
        const completedSessionIds = new Set(allProgress.filter(p => p.completed).map(p => p.sessionId));
        const completedModuleSessions = moduleSessions.filter(s => completedSessionIds.has(s.id));
        
        if (completedModuleSessions.length === moduleSessions.length) {
          if (session.moduleId === "module-1" && !unlockedAchievementIds.has("achievement-2")) {
            await storage.createStudentAchievement({
              studentId,
              achievementId: "achievement-2",
            });
          }
          if (session.moduleId === "module-3" && !unlockedAchievementIds.has("achievement-4")) {
            await storage.createStudentAchievement({
              studentId,
              achievementId: "achievement-4",
            });
          }
          if (session.moduleId === "module-4" && !unlockedAchievementIds.has("achievement-5")) {
            await storage.createStudentAchievement({
              studentId,
              achievementId: "achievement-5",
            });
          }
        }
      }

      const allModules = await storage.getAllModules();
      const allSessions = await storage.getAllSessions();
      const allCompleted = allSessions.every(s => allProgress.some(p => p.sessionId === s.id && p.completed));
      if (allCompleted && !unlockedAchievementIds.has("achievement-6")) {
        await storage.createStudentAchievement({
          studentId,
          achievementId: "achievement-6",
        });
      }

      res.json({ progress, leaderboardEntry: updatedLeaderboard });
    } catch (error) {
      res.status(400).json({ error: "Failed to complete session" });
    }
  });

  app.get("/api/achievements", async (_req, res) => {
    try {
      const achievements = await storage.getAllAchievements();
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievements" });
    }
  });

  app.get("/api/student-achievements/:studentId", async (req, res) => {
    try {
      const studentId = req.params.studentId === "current-student" ? "demo-student" : req.params.studentId;
      const achievements = await storage.getStudentAchievements(studentId);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch student achievements" });
    }
  });

  app.get("/api/leaderboard", async (_req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
