import {
  type Module,
  type Session,
  type Progress,
  type Achievement,
  type StudentAchievement,
  type LeaderboardEntry,
  type InsertProgress,
  type InsertStudentAchievement,
  type InsertLeaderboardEntry,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getAllModules(): Promise<Module[]>;
  getModuleById(id: string): Promise<Module | undefined>;
  getAllSessions(): Promise<Session[]>;
  getSessionById(id: string): Promise<Session | undefined>;
  getSessionsByModuleId(moduleId: string): Promise<Session[]>;
  
  getProgressByStudent(studentId: string): Promise<Progress[]>;
  createProgress(progress: InsertProgress): Promise<Progress>;
  updateProgress(id: string, score: number, completed: boolean): Promise<Progress | undefined>;
  
  getAllAchievements(): Promise<Achievement[]>;
  getStudentAchievements(studentId: string): Promise<StudentAchievement[]>;
  createStudentAchievement(achievement: InsertStudentAchievement): Promise<StudentAchievement>;
  
  getLeaderboard(): Promise<LeaderboardEntry[]>;
  getOrCreateLeaderboardEntry(studentId: string): Promise<LeaderboardEntry>;
  updateLeaderboardEntry(studentId: string, totalScore: number, completedSessions: number): Promise<LeaderboardEntry | undefined>;
}

export class MemStorage implements IStorage {
  private modules: Map<string, Module>;
  private sessions: Map<string, Session>;
  private progress: Map<string, Progress>;
  private achievements: Map<string, Achievement>;
  private studentAchievements: Map<string, StudentAchievement>;
  private leaderboard: Map<string, LeaderboardEntry>;

  constructor() {
    this.modules = new Map();
    this.sessions = new Map();
    this.progress = new Map();
    this.achievements = new Map();
    this.studentAchievements = new Map();
    this.leaderboard = new Map();
    
    this.seedData();
  }

  private seedData() {
    const modules: Module[] = [
      {
        id: "module-1",
        title: "Word Discovery",
        emoji: "Search",
        description: "Learn your first 10 vocabulary words through fun activities",
        duration: "2 hours",
        order: 1,
        color: "coral",
      },
      {
        id: "module-2",
        title: "Words in Action",
        emoji: "Zap",
        description: "Build sentences and practice using your new words",
        duration: "2 hours",
        order: 2,
        color: "turquoise",
      },
      {
        id: "module-3",
        title: "Words in Stories",
        emoji: "BookOpen",
        description: "Read exciting stories featuring your vocabulary words",
        duration: "2 hours",
        order: 3,
        color: "yellow",
      },
      {
        id: "module-4",
        title: "Word Creation",
        emoji: "Pencil",
        description: "Write your own stories using all the words you've learned",
        duration: "2.5 hours",
        order: 4,
        color: "purple",
      },
      {
        id: "module-5",
        title: "Word Mastery",
        emoji: "Trophy",
        description: "Master pronunciation and reading fluency",
        duration: "1.5 hours",
        order: 5,
        color: "green",
      },
    ];

    modules.forEach((module) => this.modules.set(module.id, module));

    const sessions: Session[] = [
      {
        id: "session-1a",
        moduleId: "module-1",
        title: "Introduction & First 10 Words",
        duration: "1 hr",
        order: 1,
        content: `<h2>Welcome to Word Discovery! 🎉</h2>
          <p>Get ready to learn 10 amazing new words that will help you express yourself better!</p>
          <h3>Your First 10 Words:</h3>
          <ol>
            <li><strong>Joyful</strong> - feeling very happy</li>
            <li><strong>Brave</strong> - having courage</li>
            <li><strong>Discover</strong> - to find something new</li>
            <li><strong>Beautiful</strong> - very pretty</li>
            <li><strong>Adventure</strong> - an exciting experience</li>
            <li><strong>Creative</strong> - good at making new things</li>
            <li><strong>Friendly</strong> - kind and nice to others</li>
            <li><strong>Curious</strong> - wanting to learn new things</li>
            <li><strong>Sparkle</strong> - to shine brightly</li>
            <li><strong>Wonder</strong> - a feeling of amazement</li>
          </ol>
          <p>Great job! Now let's practice using these words!</p>`,
        type: "reading",
      },
      {
        id: "session-1b",
        moduleId: "module-1",
        title: "Practice & Assessment",
        duration: "1 hr",
        order: 2,
        content: `<h2>Practice Time! 🎯</h2>
          <p>Now that you've learned 10 new words, let's see how well you remember them!</p>
          <p>You'll answer 5 questions to test your knowledge. Don't worry - you can always review the words and try again!</p>
          <p>Click continue to start your quiz!</p>`,
        type: "assessment",
      },
      {
        id: "session-2a",
        moduleId: "module-2",
        title: "Sentence Building",
        duration: "1 hr",
        order: 1,
        content: `<h2>Building Amazing Sentences! ✨</h2>
          <p>Now that you know these wonderful words, let's learn how to use them in sentences!</p>
          <h3>Example Sentences:</h3>
          <ul>
            <li>I felt <strong>joyful</strong> when I found my lost toy.</li>
            <li>The <strong>brave</strong> knight went on an <strong>adventure</strong>.</li>
            <li>I love to <strong>discover</strong> new things when I'm <strong>curious</strong>.</li>
            <li>The stars <strong>sparkle</strong> in the night sky - it's so <strong>beautiful</strong>!</li>
          </ul>
          <p>See how these words make sentences more interesting? Now it's your turn to practice!</p>`,
        type: "reading",
      },
      {
        id: "session-2b",
        moduleId: "module-2",
        title: "Interactive Practice",
        duration: "1 hr",
        order: 2,
        content: `<h2>Let's Practice Together! 🎨</h2>
          <p>Time to show what you've learned! Complete these practice exercises.</p>
          <p>Get ready for some fun challenges!</p>`,
        type: "practice",
      },
      {
        id: "session-3a",
        moduleId: "module-3",
        title: "Story Reading",
        duration: "1 hr",
        order: 1,
        content: `<h2>The Brave Explorer 🗺️</h2>
          <p>Once upon a time, there was a <strong>curious</strong> girl named Maya who loved to <strong>discover</strong> new places.</p>
          <p>One <strong>beautiful</strong> morning, she decided to go on an <strong>adventure</strong> in the forest. She felt <strong>joyful</strong> as she walked among the trees.</p>
          <p>Suddenly, she saw something <strong>sparkle</strong> in the bushes. Being <strong>brave</strong>, she walked closer. It was a <strong>friendly</strong> firefly!</p>
          <p>Maya watched in <strong>wonder</strong> as more fireflies appeared, creating a <strong>creative</strong> light show just for her.</p>
          <p>What an amazing adventure!</p>`,
        type: "reading",
      },
      {
        id: "session-3b",
        moduleId: "module-3",
        title: "Comprehension Activities",
        duration: "1 hr",
        order: 2,
        content: `<h2>Story Comprehension 📚</h2>
          <p>You just read "The Brave Explorer"! Let's see how well you understood the story.</p>
          <p>Answer these questions about Maya's adventure!</p>`,
        type: "assessment",
      },
    ];

    sessions.forEach((session) => this.sessions.set(session.id, session));

    const achievements: Achievement[] = [
      {
        id: "achievement-1",
        title: "First Steps",
        description: "Complete your first session",
        emoji: "Target",
        color: "coral",
        requirement: "complete-1-session",
      },
      {
        id: "achievement-2",
        title: "Word Explorer",
        description: "Complete Module 1",
        emoji: "Compass",
        color: "turquoise",
        requirement: "complete-module-1",
      },
      {
        id: "achievement-3",
        title: "Perfect Score",
        description: "Get 100% on any quiz",
        emoji: "Award",
        color: "yellow",
        requirement: "perfect-score",
      },
      {
        id: "achievement-4",
        title: "Story Master",
        description: "Complete Module 3",
        emoji: "BookOpen",
        color: "purple",
        requirement: "complete-module-3",
      },
      {
        id: "achievement-5",
        title: "Creative Writer",
        description: "Complete Module 4",
        emoji: "Pencil",
        color: "green",
        requirement: "complete-module-4",
      },
      {
        id: "achievement-6",
        title: "Word Champion",
        description: "Complete all modules",
        emoji: "Crown",
        color: "coral",
        requirement: "complete-all-modules",
      },
    ];

    achievements.forEach((achievement) =>
      this.achievements.set(achievement.id, achievement)
    );

    const demoStudents: LeaderboardEntry[] = [
      {
        id: randomUUID(),
        studentId: "demo-1",
        studentName: "Alex",
        totalScore: 450,
        completedSessions: 5,
        avatarColor: "#FF6B6B",
      },
      {
        id: randomUUID(),
        studentId: "demo-2",
        studentName: "Emma",
        totalScore: 380,
        completedSessions: 4,
        avatarColor: "#4ECDC4",
      },
      {
        id: randomUUID(),
        studentId: "demo-3",
        studentName: "Liam",
        totalScore: 320,
        completedSessions: 3,
        avatarColor: "#FFE66D",
      },
    ];

    demoStudents.forEach((student) =>
      this.leaderboard.set(student.studentId, student)
    );
  }

  async getAllModules(): Promise<Module[]> {
    return Array.from(this.modules.values()).sort((a, b) => a.order - b.order);
  }

  async getModuleById(id: string): Promise<Module | undefined> {
    return this.modules.get(id);
  }

  async getAllSessions(): Promise<Session[]> {
    return Array.from(this.sessions.values());
  }

  async getSessionById(id: string): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async getSessionsByModuleId(moduleId: string): Promise<Session[]> {
    return Array.from(this.sessions.values())
      .filter((session) => session.moduleId === moduleId)
      .sort((a, b) => a.order - b.order);
  }

  async getProgressByStudent(studentId: string): Promise<Progress[]> {
    return Array.from(this.progress.values()).filter(
      (p) => p.studentId === studentId
    );
  }

  async createProgress(insertProgress: InsertProgress): Promise<Progress> {
    const id = randomUUID();
    const progress: Progress = {
      ...insertProgress,
      id,
      completedAt: insertProgress.completed ? new Date() : null,
    };
    this.progress.set(id, progress);
    return progress;
  }

  async updateProgress(
    id: string,
    score: number,
    completed: boolean
  ): Promise<Progress | undefined> {
    const progress = this.progress.get(id);
    if (!progress) return undefined;

    const updated: Progress = {
      ...progress,
      score,
      completed,
      completedAt: completed ? new Date() : null,
    };
    this.progress.set(id, updated);
    return updated;
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getStudentAchievements(
    studentId: string
  ): Promise<StudentAchievement[]> {
    return Array.from(this.studentAchievements.values()).filter(
      (sa) => sa.studentId === studentId
    );
  }

  async createStudentAchievement(
    insertAchievement: InsertStudentAchievement
  ): Promise<StudentAchievement> {
    const id = randomUUID();
    const achievement: StudentAchievement = {
      ...insertAchievement,
      id,
      unlockedAt: new Date(),
    };
    this.studentAchievements.set(id, achievement);
    return achievement;
  }

  async getLeaderboard(): Promise<LeaderboardEntry[]> {
    return Array.from(this.leaderboard.values()).sort(
      (a, b) => b.totalScore - a.totalScore
    );
  }

  async getOrCreateLeaderboardEntry(
    studentId: string
  ): Promise<LeaderboardEntry> {
    const existing = this.leaderboard.get(studentId);
    if (existing) return existing;

    const colors = ["#FF6B6B", "#4ECDC4", "#FFE66D", "#9B59B6", "#2ECC71"];
    const entry: LeaderboardEntry = {
      id: randomUUID(),
      studentId,
      studentName: `Student ${studentId.substring(0, 4)}`,
      totalScore: 0,
      completedSessions: 0,
      avatarColor: colors[Math.floor(Math.random() * colors.length)],
    };
    this.leaderboard.set(studentId, entry);
    return entry;
  }

  async updateLeaderboardEntry(
    studentId: string,
    totalScore: number,
    completedSessions: number
  ): Promise<LeaderboardEntry | undefined> {
    const entry = this.leaderboard.get(studentId);
    if (!entry) return undefined;

    const updated: LeaderboardEntry = {
      ...entry,
      totalScore,
      completedSessions,
    };
    this.leaderboard.set(studentId, updated);
    return updated;
  }
}

export const storage = new MemStorage();
