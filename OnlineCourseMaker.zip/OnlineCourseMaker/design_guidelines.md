# Design Guidelines for "The Vocabulary Quest"

## Design Approach
**Reference-Based Gamification**: Drawing inspiration from successful educational gaming platforms like Duolingo, Khan Academy Kids, and ABCmouse to create an engaging, playful learning environment that doesn't feel like traditional education.

## Core Design Principles
1. **Game-First Mentality**: Every element should feel like part of a game, not a school website
2. **Instant Gratification**: Visual feedback, animations, and rewards for every interaction
3. **Joyful Chaos**: Embrace colorful, energetic design over corporate minimalism
4. **Age-Appropriate**: Large touch targets, simple navigation, lots of visual cues

## Color System
- **Primary Palette**: 
  - Coral Red: #FF6B6B (action buttons, important elements)
  - Turquoise: #4ECDC4 (progress, success states)
  - Yellow: #FFE66D (highlights, achievements)
- **Usage**: Use all three colors liberally throughout - this is not a minimalist design. Mix and match for different modules/sections.

## Typography
- **Headers**: Large, rounded, playful fonts (like Fredoka, Baloo, or Nunito)
- **Body Text**: Clear, readable rounded sans-serif
- **Sizes**: Go big - headers should be 2.5-3rem minimum, body text 1.125rem minimum for readability
- **Emojis**: Use generously throughout (🎮 🏆 ⭐ 🚀 📚 🎯 🎨 ✨) as visual markers and icons

## Layout System
- **Spacing**: Generous padding using Tailwind units of 4, 6, and 8 (p-4, p-6, p-8)
- **Card-Based**: Everything lives in rounded, colorful cards with shadows
- **Grid**: 1 column mobile, 2-3 columns tablet, up to 5 columns desktop for module cards

## Component Library

**Module Cards** (5 total):
- Large rounded cards with emoji icons
- Module title, session count, time estimate
- Lock icon for incomplete prerequisites
- Hover: slight scale-up animation, shadow increase

**Progress Tracking**:
- Animated progress bars with percentage
- Circular progress indicators for individual modules
- Star rating system for completed sessions

**Achievement Badges**:
- Colorful badge cards with icons/emojis
- Unlock animations when earned
- Grid layout showing locked and unlocked badges

**Leaderboard**:
- Top 10 students with avatar placeholders
- Score display with star icons
- Highlighting for current user's position

**Animated Title**:
- Large, bouncy heading animation on page load
- Gradient or multi-color text treatment

**Buttons**:
- Large, rounded buttons with bright colors
- Hover: subtle scale, brightness increase
- Active state: slight press-down effect
- High contrast text for readability

## Responsive Strategy
- **Mobile (base)**: Single column, stacked cards, full-width buttons
- **Tablet (md:)**: 2 column grid for modules, side-by-side layouts
- **Desktop (lg:)**: 3-5 column grids, wider max-width containers

## Images
No hero images needed - this is a dashboard/game interface. Use emoji, icons, and colorful graphics instead of photography. Focus on illustrated elements and game-like visuals.

## Animation Guidelines
- **Entrance animations**: Cards fade and slide in on load
- **Hover effects**: Scale, glow, and bounce on interactive elements
- **Progress**: Smooth animated fills for progress bars
- **Rewards**: Celebratory animations (confetti, stars) for achievements
- Keep animations quick (200-300ms) and playful

## Critical Requirements
- Touch-friendly: 44px minimum touch targets
- High contrast text on colorful backgrounds
- Visual hierarchy through size, color, and animation
- Clear feedback for every interaction
- Optimistic, encouraging tone throughout