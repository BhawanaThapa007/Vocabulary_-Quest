import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const modules = pgTable("modules", {
  id: varchar("id").primaryKey(),
  title: text("title").notNull(),
  emoji: text("emoji").notNull(),
  description: text("description").notNull(),
  duration: text("duration").notNull(),
  order: integer("order").notNull(),
  color: text("color").notNull(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey(),
  moduleId: varchar("module_id").notNull(),
  title: text("title").notNull(),
  duration: text("duration").notNull(),
  order: integer("order").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(),
});

export const progress = pgTable("progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull(),
  sessionId: varchar("session_id").notNull(),
  completed: boolean("completed").notNull().default(false),
  score: integer("score"),
  completedAt: timestamp("completed_at"),
});

export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  emoji: text("emoji").notNull(),
  color: text("color").notNull(),
  requirement: text("requirement").notNull(),
});

export const studentAchievements = pgTable("student_achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull(),
  achievementId: varchar("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").notNull().default(sql`now()`),
});

export const leaderboard = pgTable("leaderboard", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().unique(),
  studentName: text("student_name").notNull(),
  totalScore: integer("total_score").notNull().default(0),
  completedSessions: integer("completed_sessions").notNull().default(0),
  avatarColor: text("avatar_color").notNull(),
});

export type Module = typeof modules.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type Progress = typeof progress.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type StudentAchievement = typeof studentAchievements.$inferSelect;
export type LeaderboardEntry = typeof leaderboard.$inferSelect;

export const insertProgressSchema = createInsertSchema(progress).omit({ id: true });
export const insertStudentAchievementSchema = createInsertSchema(studentAchievements).omit({ id: true, unlockedAt: true });
export const insertLeaderboardSchema = createInsertSchema(leaderboard).omit({ id: true });

export type InsertProgress = z.infer<typeof insertProgressSchema>;
export type InsertStudentAchievement = z.infer<typeof insertStudentAchievementSchema>;
export type InsertLeaderboardEntry = z.infer<typeof insertLeaderboardSchema>;
