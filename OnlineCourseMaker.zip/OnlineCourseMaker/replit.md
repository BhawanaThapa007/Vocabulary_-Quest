# The Vocabulary Quest

## Overview

The Vocabulary Quest is a gamified vocabulary learning platform designed for elementary students. The application provides an engaging, playful learning environment inspired by successful educational platforms like Duolingo and Khan Academy Kids. Students progress through vocabulary modules, complete interactive sessions, earn achievements, and compete on leaderboards.

The application follows a game-first design philosophy with colorful cards, animated progress tracking, achievement badges, and instant visual feedback to maintain student engagement.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript, using Vite as the build tool and development server.

**Routing**: Client-side routing implemented with Wouter for lightweight navigation between pages (Home, Module Detail, Lesson).

**State Management**: TanStack Query (React Query) for server state management, providing caching, background updates, and simplified data fetching patterns.

**UI Components**: Radix UI primitives with shadcn/ui component library for accessible, customizable components following the "new-york" style variant.

**Styling**: Tailwind CSS with custom design tokens for the gamified theme, including custom color palette (Coral Red #FF6B6B, Turquoise #4ECDC4, Yellow #FFE66D) and rounded, playful design system.

**Typography**: Google Fonts integration (Nunito and Fredoka) for large, readable, playful text appropriate for elementary students.

**Animations**: Framer Motion for interactive animations, transitions, and visual feedback. Canvas-confetti for celebration effects on achievements.

**Design Philosophy**: Card-based layout with generous spacing, large touch targets for children, emoji-rich visual markers, and colorful gradient backgrounds. Components emphasize instant gratification through animations and visual rewards.

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**API Design**: RESTful API endpoints for modules, sessions, progress tracking, achievements, and leaderboard data.

**Data Storage**: In-memory storage implementation (MemStorage class) for development, with interface (IStorage) designed to support future database integration. The schema is defined using Drizzle ORM with PostgreSQL dialect.

**Session Management**: Express middleware for request logging and JSON body parsing with raw body preservation for potential webhook integrations.

**Development**: Hot Module Replacement (HMR) via Vite middleware integration, custom error overlay, and Replit-specific development tooling.

**API Endpoints**:
- `/api/modules` - Fetch all vocabulary modules
- `/api/modules/:id` - Get specific module details
- `/api/modules/:id/sessions` - Get sessions for a module
- `/api/sessions/:id` - Get specific session details
- `/api/progress/:studentId` - Student progress tracking
- `/api/leaderboard` - Leaderboard rankings
- `/api/achievements` - Achievement definitions
- `/api/student-achievements/:studentId` - Student's unlocked achievements

### Data Models

**Modules**: Vocabulary learning units with title, emoji icon, description, duration, sequential ordering, and color theming.

**Sessions**: Individual lessons within modules, supporting different types (lesson, practice, assessment) with content and duration metadata.

**Progress**: Tracks student completion status, scores, and timestamps for each session.

**Achievements**: Gamification badges with unlock requirements, descriptions, and visual styling.

**Leaderboard**: Student rankings based on total score and completed sessions.

All schemas defined with Drizzle ORM using PostgreSQL-compatible types, with Zod validation schemas for runtime type checking.

### Design System

**Color Tokens**: HSL-based color system with CSS custom properties for theming, supporting both light and dark modes.

**Component Variants**: Class Variance Authority (CVA) for type-safe component variants and styling composition.

**Accessibility**: Radix UI primitives ensure WCAG compliance with keyboard navigation, screen reader support, and proper ARIA attributes.

**Responsive Design**: Mobile-first approach with breakpoint-based layouts (1 column mobile, 2-3 columns tablet, up to 5 columns desktop for module cards).

## External Dependencies

### Database
- **Drizzle ORM**: Type-safe ORM configured for PostgreSQL
- **@neondatabase/serverless**: PostgreSQL client optimized for serverless environments
- **connect-pg-simple**: PostgreSQL session store (configured but not currently active)

### UI Libraries
- **Radix UI**: Comprehensive collection of accessible component primitives (@radix-ui/react-*)
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Framer Motion**: Animation library for interactive UI elements
- **canvas-confetti**: Visual celebration effects

### Utilities
- **TanStack Query**: Server state management and caching
- **Wouter**: Lightweight client-side routing
- **Zod**: Runtime type validation and schema validation
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: Utility for conditional CSS class composition

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across frontend and backend
- **ESBuild**: JavaScript bundler for production builds
- **@replit/vite-plugin-***: Replit-specific development enhancements (cartographer, dev banner, error overlay)

### Fonts
- **Google Fonts**: Nunito (primary sans-serif) and Fredoka (headings) for playful, child-friendly typography