import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Session } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Star, CheckCircle2, BookOpen, Sparkles, Target } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import QuizComponent from "@/components/quiz-component";

export default function Lesson() {
  const [, params] = useRoute("/lesson/:id");
  const [, setLocation] = useLocation();
  const sessionId = params?.id;
  const { toast } = useToast();
  const [showQuiz, setShowQuiz] = useState(false);

  const { data: session } = useQuery<Session>({
    queryKey: ["/api/sessions", sessionId],
  });

  const completeSessionMutation = useMutation({
    mutationFn: async (data: { sessionId: string; score: number }) => {
      return apiRequest("POST", "/api/progress/complete", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      toast({
        title: "Session Completed!",
        description: "Great job! You earned stars for completing this session.",
      });
    },
  });

  const handleComplete = (score: number) => {
    if (sessionId) {
      completeSessionMutation.mutate({ sessionId, score });
    }
  };

  const handleNext = () => {
    if (session?.type === "assessment" || session?.type === "practice") {
      setShowQuiz(true);
    } else {
      handleComplete(100);
      setTimeout(() => {
        setLocation(`/module/${session?.moduleId}`);
      }, 1500);
    }
  };

  if (!session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950 dark:via-purple-950 dark:to-pink-950 flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-16 h-16 mx-auto mb-4 animate-bounce text-primary" />
          <p className="text-xl font-heading font-bold">Loading lesson...</p>
        </div>
      </div>
    );
  }

  if (showQuiz) {
    return (
      <QuizComponent
        session={session}
        onComplete={(score) => {
          handleComplete(score);
          setTimeout(() => {
            setLocation(`/module/${session.moduleId}`);
          }, 2000);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950 dark:via-purple-950 dark:to-pink-950">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Button
          variant="ghost"
          className="mb-6 gap-2"
          onClick={() => setLocation(`/module/${session.moduleId}`)}
          data-testid="button-back-module"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Module
        </Button>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="p-8 md:p-12 bg-card/80 backdrop-blur border-2 mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Star className="w-6 h-6 text-game-yellow fill-game-yellow" />
              <h1 className="text-3xl md:text-4xl font-heading font-bold text-foreground" data-testid="heading-lesson-title">
                {session.title}
              </h1>
            </div>

            <div className="prose prose-lg max-w-none dark:prose-invert">
              <div
                className="text-foreground leading-relaxed"
                dangerouslySetInnerHTML={{ __html: session.content }}
                data-testid="content-lesson"
              />
            </div>

            {session.type === "reading" && (
              <div className="mt-8 p-6 bg-game-turquoise/10 rounded-lg border-2 border-game-turquoise/30">
                <h3 className="text-xl font-heading font-bold text-foreground mb-3 flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Key Vocabulary
                </h3>
                <p className="text-muted-foreground">
                  Pay attention to the highlighted words in the story. These are your vocabulary words for today!
                </p>
              </div>
            )}

            {session.type === "practice" && (
              <div className="mt-8 p-6 bg-game-yellow/10 rounded-lg border-2 border-game-yellow/30">
                <h3 className="text-xl font-heading font-bold text-foreground mb-3 flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Practice Time!
                </h3>
                <p className="text-muted-foreground">
                  Get ready to practice what you've learned. Click "Continue" to start the interactive exercises!
                </p>
              </div>
            )}
          </Card>

          <div className="flex justify-between items-center gap-4">
            <Button
              variant="outline"
              className="gap-2"
              onClick={() => setLocation(`/module/${session.moduleId}`)}
              data-testid="button-exit"
            >
              Exit Lesson
            </Button>
            <Button
              className="gap-2 text-lg px-8 py-6"
              onClick={handleNext}
              disabled={completeSessionMutation.isPending}
              data-testid="button-continue"
            >
              {session.type === "assessment" || session.type === "practice" ? (
                <>
                  Start {session.type === "assessment" ? "Quiz" : "Practice"}
                  <ChevronRight className="w-5 h-5" />
                </>
              ) : (
                <>
                  {completeSessionMutation.isPending ? (
                    "Saving..."
                  ) : (
                    <>
                      Complete & Continue
                      <CheckCircle2 className="w-5 h-5" />
                    </>
                  )}
                </>
              )}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
