import { useQuery } from "@tanstack/react-query";
import { Module, LeaderboardEntry, Achievement, StudentAchievement } from "@shared/schema";
import ModuleCard from "@/components/module-card";
import ProgressTracker from "@/components/progress-tracker";
import AchievementBadges from "@/components/achievement-badges";
import Leaderboard from "@/components/leaderboard";
import { Sparkles, Trophy, BookOpen } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: modules, isLoading: modulesLoading } = useQuery<Module[]>({
    queryKey: ["/api/modules"],
  });

  const { data: progress } = useQuery({
    queryKey: ["/api/progress", "current-student"],
  });

  const { data: leaderboardData } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard"],
  });

  const { data: achievements } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
  });

  const { data: studentAchievements } = useQuery<StudentAchievement[]>({
    queryKey: ["/api/student-achievements", "current-student"],
  });

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950 dark:via-purple-950 dark:to-pink-950">
      <div className="container mx-auto px-4 py-8 md:py-12 max-w-7xl">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, type: "spring", bounce: 0.4 }}
          className="text-center mb-8 md:mb-12"
        >
          <div className="inline-flex items-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 md:w-12 md:h-12 text-game-coral animate-pulse-slow" />
            <h1
              className="text-4xl md:text-6xl lg:text-7xl font-heading font-bold bg-gradient-to-r from-game-coral via-game-turquoise to-game-yellow bg-clip-text text-transparent animate-bounce-slow"
              data-testid="heading-title"
            >
              The Vocabulary Quest
            </h1>
            <Trophy className="w-8 h-8 md:w-12 md:h-12 text-game-yellow animate-pulse-slow" />
          </div>
          <p className="text-lg md:text-xl text-muted-foreground font-body font-semibold" data-testid="text-subtitle">
            Learn words, earn rewards, become a word master!
          </p>
        </motion.div>

        <ProgressTracker progress={progress} modules={modules} />

        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="mb-12"
        >
          <h2 className="text-2xl md:text-3xl font-heading font-bold text-foreground mb-6 flex items-center gap-2">
            <BookOpen className="w-6 h-6 md:w-8 md:h-8" />
            Your Learning Modules
          </h2>
          {modulesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="h-64 bg-card rounded-xl animate-pulse"
                  data-testid={`skeleton-module-${i}`}
                />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
              {modules?.map((module) => (
                <motion.div key={module.id} variants={item}>
                  <ModuleCard module={module} progress={progress} />
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <AchievementBadges
            achievements={achievements}
            studentAchievements={studentAchievements}
          />
          <Leaderboard data={leaderboardData} />
        </div>
      </div>
    </div>
  );
}
