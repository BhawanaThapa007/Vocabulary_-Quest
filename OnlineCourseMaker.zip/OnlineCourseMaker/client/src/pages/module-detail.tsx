import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Module, Session } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ChevronLeft, Play, CheckCircle2, Lock, Clock, Search, Zap, BookOpen, Pencil, Trophy } from "lucide-react";
import { motion } from "framer-motion";

const iconMap: Record<string, any> = {
  Search,
  Zap,
  BookOpen,
  Pencil,
  Trophy,
};

export default function ModuleDetail() {
  const [, params] = useRoute("/module/:id");
  const moduleId = params?.id;

  const { data: module } = useQuery<Module>({
    queryKey: ["/api/modules", moduleId],
  });

  const { data: sessions } = useQuery<Session[]>({
    queryKey: ["/api/modules", moduleId, "sessions"],
  });

  const { data: progress } = useQuery({
    queryKey: ["/api/progress", "current-student"],
  });

  const completedSessionIds = new Set(
    progress?.progress?.filter((p: any) => p.completed).map((p: any) => p.sessionId) || []
  );
  const moduleProgress = progress?.moduleProgress?.[moduleId || ""] || 0;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
      },
    },
  };

  const item = {
    hidden: { x: -20, opacity: 0 },
    show: { x: 0, opacity: 1 },
  };

  if (!module) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950 dark:via-purple-950 dark:to-pink-950 flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-16 h-16 mx-auto mb-4 animate-bounce text-primary" />
          <p className="text-xl font-heading font-bold">Loading module...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950 dark:via-purple-950 dark:to-pink-950">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Link href="/">
          <Button variant="ghost" className="mb-6 gap-2" data-testid="button-back-home">
            <ChevronLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <Card className="p-8 bg-gradient-to-br from-game-coral/10 via-game-turquoise/10 to-game-yellow/10 border-2 border-primary/20">
            <div className="flex items-start gap-4 mb-6">
              <div className="flex items-center justify-center" data-testid="icon-module">
                {iconMap[module.emoji] && (() => {
                  const IconComponent = iconMap[module.emoji];
                  return <IconComponent className="w-16 h-16 md:w-20 md:h-20" />;
                })()}
              </div>
              <div className="flex-1">
                <h1 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-2" data-testid="heading-module-title">
                  Module {module.order}: {module.title}
                </h1>
                <p className="text-lg text-muted-foreground mb-4" data-testid="text-module-description">
                  {module.description}
                </p>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {module.duration}
                  </span>
                  <span>{sessions?.length || 0} Sessions</span>
                </div>
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-foreground">Module Progress</span>
                <span className="text-sm font-bold text-foreground">{moduleProgress}%</span>
              </div>
              <Progress value={moduleProgress} className="h-3" data-testid="progress-module" />
            </div>
          </Card>
        </motion.div>

        <h2 className="text-2xl font-heading font-bold text-foreground mb-6 flex items-center gap-2">
          <BookOpen className="w-6 h-6" />
          Sessions
        </h2>
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="space-y-4"
        >
          {sessions?.map((session, index) => {
            const isCompleted = completedSessionIds.has(session.id);
            const isUnlocked = index === 0 || completedSessionIds.has(sessions[index - 1]?.id);

            return (
              <motion.div key={session.id} variants={item}>
                <Card
                  className={`p-6 border-2 hover-elevate ${
                    isCompleted
                      ? "bg-green-50 dark:bg-green-950/20 border-green-400/50"
                      : isUnlocked
                      ? "bg-card border-card-border"
                      : "bg-muted/50 border-border opacity-60"
                  }`}
                  data-testid={`card-session-${session.id}`}
                >
                  <div className="flex items-center gap-4">
                    <div className="flex-shrink-0">
                      {isCompleted ? (
                        <CheckCircle2 className="w-8 h-8 text-green-500" data-testid={`icon-completed-${session.id}`} />
                      ) : isUnlocked ? (
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                          <span className="font-bold text-primary">{session.order}</span>
                        </div>
                      ) : (
                        <Lock className="w-8 h-8 text-muted-foreground" data-testid={`icon-locked-${session.id}`} />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-heading font-bold text-foreground mb-1" data-testid={`text-session-title-${session.id}`}>
                        Session {session.order}: {session.title}
                      </h3>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {session.duration}
                        </span>
                        <span className="capitalize">{session.type}</span>
                      </div>
                    </div>
                    {isUnlocked ? (
                      <Link href={`/lesson/${session.id}`}>
                        <Button className="gap-2" data-testid={`button-start-session-${session.id}`}>
                          <Play className="w-4 h-4" />
                          {isCompleted ? "Review" : "Start"}
                        </Button>
                      </Link>
                    ) : (
                      <Button disabled className="gap-2" data-testid={`button-locked-session-${session.id}`}>
                        <Lock className="w-4 h-4" />
                        Locked
                      </Button>
                    )}
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </div>
  );
}
