import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Module } from "@shared/schema";
import { Star, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

interface ProgressTrackerProps {
  progress?: any;
  modules?: Module[];
}

export default function ProgressTracker({ progress, modules }: ProgressTrackerProps) {
  const totalSessions = 12;
  const completedSessions = progress?.completedSessions || 0;
  const overallProgress = Math.round((completedSessions / totalSessions) * 100);
  const totalStars = progress?.totalStars || 0;

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="mb-8"
    >
      <Card className="p-6 md:p-8 bg-gradient-to-r from-game-coral/10 via-game-turquoise/10 to-game-yellow/10 border-2 border-primary/20">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex-1 w-full">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xl font-heading font-bold text-foreground flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-game-turquoise" />
                Your Progress
              </h3>
              <span className="text-3xl font-heading font-bold bg-gradient-to-r from-game-coral to-game-yellow bg-clip-text text-transparent" data-testid="text-progress-percentage">
                {overallProgress}%
              </span>
            </div>
            <Progress value={overallProgress} className="h-4 mb-3" data-testid="progress-overall" />
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2" data-testid="text-completed-sessions">
                <span className="font-semibold text-muted-foreground">Sessions:</span>
                <span className="font-bold text-foreground">{completedSessions}/{totalSessions}</span>
              </div>
              <div className="flex items-center gap-2" data-testid="text-total-stars">
                <Star className="w-4 h-4 text-game-yellow fill-game-yellow" />
                <span className="font-bold text-foreground">{totalStars} Stars Earned</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
