import { Achievement, StudentAchievement } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lock, Target, Compass, Award, BookOpen, Pencil, Crown, Trophy } from "lucide-react";
import { motion } from "framer-motion";

const iconMap: Record<string, any> = {
  Target,
  Compass,
  Award,
  BookOpen,
  Pencil,
  Crown,
};

interface AchievementBadgesProps {
  achievements?: Achievement[];
  studentAchievements?: StudentAchievement[];
}

export default function AchievementBadges({ achievements, studentAchievements }: AchievementBadgesProps) {
  const unlockedIds = new Set(studentAchievements?.map(sa => sa.achievementId) || []);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  };

  const item = {
    hidden: { scale: 0.8, opacity: 0 },
    show: { scale: 1, opacity: 1 },
  };

  return (
    <Card className="p-6 bg-card/50 backdrop-blur">
      <h2 className="text-2xl font-heading font-bold text-foreground mb-4 flex items-center gap-2">
        <Trophy className="w-6 h-6" />
        Achievement Badges
      </h2>
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-2 sm:grid-cols-3 gap-4"
      >
        {achievements?.slice(0, 6).map((achievement) => {
          const isUnlocked = unlockedIds.has(achievement.id);
          return (
            <motion.div key={achievement.id} variants={item}>
              <div
                className={`relative p-4 rounded-lg border-2 text-center transition-all ${
                  isUnlocked
                    ? `bg-gradient-to-br from-${achievement.color}-400/20 to-${achievement.color}-400/10 border-${achievement.color}-400/50 hover-elevate`
                    : "bg-muted/50 border-border opacity-50"
                }`}
                data-testid={`badge-achievement-${achievement.id}`}
              >
                {!isUnlocked && (
                  <div className="absolute top-2 right-2">
                    <Lock className="w-4 h-4 text-muted-foreground" />
                  </div>
                )}
                <div className="flex items-center justify-center mb-2" data-testid={`icon-achievement-${achievement.id}`}>
                  {iconMap[achievement.emoji] && (() => {
                    const IconComponent = iconMap[achievement.emoji];
                    return <IconComponent className="w-12 h-12" />;
                  })()}
                </div>
                <h4 className="font-heading font-bold text-sm mb-1" data-testid={`text-achievement-title-${achievement.id}`}>
                  {achievement.title}
                </h4>
                <p className="text-xs text-muted-foreground line-clamp-2" data-testid={`text-achievement-description-${achievement.id}`}>
                  {achievement.description}
                </p>
              </div>
            </motion.div>
          );
        })}
      </motion.div>
      <div className="mt-6 flex items-center gap-2">
        <Badge variant="secondary" className="text-base px-4 py-2 font-bold" data-testid="badge-unlocked-count">
          {unlockedIds.size}/{achievements?.length || 0} Unlocked
        </Badge>
      </div>
    </Card>
  );
}
