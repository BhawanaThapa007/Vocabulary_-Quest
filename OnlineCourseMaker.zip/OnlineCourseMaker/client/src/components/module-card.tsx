import { Module } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lock, Play, CheckCircle2, Search, Zap, BookOpen, Pencil, Trophy } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

const iconMap: Record<string, any> = {
  Search,
  Zap,
  BookOpen,
  Pencil,
  Trophy,
};

interface ModuleCardProps {
  module: Module;
  progress?: any;
}

export default function ModuleCard({ module, progress }: ModuleCardProps) {
  const isUnlocked = module.order === 1 || progress?.completedModules?.includes(module.order - 1);
  const isCompleted = progress?.completedModules?.includes(module.order);
  const completionPercentage = progress?.moduleProgress?.[module.id] || 0;

  const bgColors: Record<string, string> = {
    coral: "bg-gradient-to-br from-game-coral/20 to-game-coral/10 border-game-coral/30",
    turquoise: "bg-gradient-to-br from-game-turquoise/20 to-game-turquoise/10 border-game-turquoise/30",
    yellow: "bg-gradient-to-br from-game-yellow/20 to-game-yellow/10 border-game-yellow/30",
    purple: "bg-gradient-to-br from-purple-400/20 to-purple-400/10 border-purple-400/30",
    green: "bg-gradient-to-br from-green-400/20 to-green-400/10 border-green-400/30",
  };

  return (
    <motion.div
      whileHover={isUnlocked ? { scale: 1.05, y: -5 } : {}}
      whileTap={isUnlocked ? { scale: 0.98 } : {}}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <Card
        className={`relative overflow-hidden border-2 ${bgColors[module.color] || bgColors.coral} p-6 h-full hover-elevate ${!isUnlocked ? "opacity-60" : ""}`}
        data-testid={`card-module-${module.id}`}
      >
        {isCompleted && (
          <div className="absolute top-3 right-3">
            <CheckCircle2 className="w-6 h-6 text-green-500" data-testid={`icon-completed-${module.id}`} />
          </div>
        )}
        
        <div className="flex flex-col items-center text-center gap-4 h-full">
          <div className="text-5xl md:text-6xl flex items-center justify-center" data-testid={`icon-${module.id}`}>
            {iconMap[module.emoji] && (
              <div>{(() => {
                const IconComponent = iconMap[module.emoji];
                return <IconComponent className="w-16 h-16 md:w-20 md:h-20" />;
              })()}</div>
            )}
          </div>
          
          <div className="flex-1">
            <h3 className="text-xl font-heading font-bold text-foreground mb-2" data-testid={`text-module-title-${module.id}`}>
              Module {module.order}: {module.title}
            </h3>
            <p className="text-sm text-muted-foreground mb-2 line-clamp-2" data-testid={`text-module-description-${module.id}`}>
              {module.description}
            </p>
            <p className="text-xs font-semibold text-muted-foreground" data-testid={`text-module-duration-${module.id}`}>
              ⏱️ {module.duration}
            </p>
          </div>

          {completionPercentage > 0 && (
            <div className="w-full">
              <div className="w-full bg-muted rounded-full h-2 mb-2">
                <div
                  className="h-2 rounded-full bg-gradient-to-r from-game-turquoise to-game-yellow transition-all duration-500"
                  style={{ width: `${completionPercentage}%` }}
                  data-testid={`progress-module-${module.id}`}
                />
              </div>
              <p className="text-xs font-semibold text-muted-foreground">
                {completionPercentage}% Complete
              </p>
            </div>
          )}

          {isUnlocked ? (
            <Link href={`/module/${module.id}`}>
              <Button
                className="w-full font-bold text-base gap-2"
                variant={isCompleted ? "secondary" : "default"}
                data-testid={`button-start-${module.id}`}
              >
                <Play className="w-4 h-4" />
                {isCompleted ? "Review" : completionPercentage > 0 ? "Continue" : "Start"}
              </Button>
            </Link>
          ) : (
            <Button className="w-full font-bold text-base gap-2" disabled data-testid={`button-locked-${module.id}`}>
              <Lock className="w-4 h-4" />
              Locked
            </Button>
          )}
        </div>
      </Card>
    </motion.div>
  );
}
