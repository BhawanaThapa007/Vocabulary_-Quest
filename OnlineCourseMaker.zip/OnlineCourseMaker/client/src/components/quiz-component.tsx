import { Session } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { CheckCircle2, XCircle, Star, Trophy } from "lucide-react";
import confetti from "canvas-confetti";

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

const sampleQuestions: Question[] = [
  {
    question: "Which word means 'happy and cheerful'?",
    options: ["Joyful", "Sad", "Angry", "Tired"],
    correctAnswer: 0,
  },
  {
    question: "What does 'brave' mean?",
    options: ["Scared", "Courageous", "Weak", "Silly"],
    correctAnswer: 1,
  },
  {
    question: "Which word is a synonym for 'big'?",
    options: ["Tiny", "Small", "Large", "Little"],
    correctAnswer: 2,
  },
  {
    question: "What does 'discover' mean?",
    options: ["To lose", "To hide", "To find", "To forget"],
    correctAnswer: 2,
  },
  {
    question: "Which word means 'very pretty'?",
    options: ["Ugly", "Beautiful", "Plain", "Dark"],
    correctAnswer: 1,
  },
];

interface QuizComponentProps {
  session: Session;
  onComplete: (score: number) => void;
}

export default function QuizComponent({ session, onComplete }: QuizComponentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const questions = sampleQuestions;
  const totalQuestions = questions.length;
  const currentQ = questions[currentQuestion];

  const handleAnswer = (index: number) => {
    setSelectedAnswer(index);
    setShowResult(true);

    const isCorrect = index === currentQ.correctAnswer;
    if (isCorrect) {
      setCorrectCount(correctCount + 1);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#FF6B6B', '#4ECDC4', '#FFE66D'],
      });
    }

    setTimeout(() => {
      if (currentQuestion < totalQuestions - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setShowResult(false);
      } else {
        const finalScore = Math.round(((correctCount + (isCorrect ? 1 : 0)) / totalQuestions) * 100);
        setIsFinished(true);
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FF6B6B', '#4ECDC4', '#FFE66D'],
        });
        setTimeout(() => onComplete(finalScore), 3000);
      }
    }, 1500);
  };

  if (isFinished) {
    const finalScore = Math.round((correctCount / totalQuestions) * 100);
    const starsEarned = Math.ceil((correctCount / totalQuestions) * 3);

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950 dark:via-purple-950 dark:to-pink-950 flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", bounce: 0.5 }}
        >
          <Card className="p-8 md:p-12 text-center max-w-lg bg-gradient-to-br from-game-yellow/20 via-game-coral/20 to-game-turquoise/20 border-4 border-game-yellow/50">
            <Trophy className="w-20 h-20 text-game-yellow mx-auto mb-4 animate-bounce" />
            <h2 className="text-4xl font-heading font-bold text-foreground mb-4">
              Amazing Work!
            </h2>
            <p className="text-2xl font-bold text-foreground mb-6">
              You scored {finalScore}%
            </p>
            <div className="flex justify-center gap-2 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-12 h-12 ${
                    i < starsEarned ? "text-game-yellow fill-game-yellow" : "text-muted"
                  }`}
                />
              ))}
            </div>
            <p className="text-lg text-muted-foreground mb-2">
              You got {correctCount} out of {totalQuestions} questions correct!
            </p>
            <p className="text-sm text-muted-foreground">
              Redirecting you back to the module...
            </p>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950 dark:via-purple-950 dark:to-pink-950">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-xl font-heading font-bold text-foreground">
              Question {currentQuestion + 1} of {totalQuestions}
            </h2>
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-game-yellow fill-game-yellow" />
              <span className="font-bold text-foreground">{correctCount} Correct</span>
            </div>
          </div>
          <div className="w-full bg-muted rounded-full h-3">
            <div
              className="h-3 rounded-full bg-gradient-to-r from-game-coral to-game-yellow transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / totalQuestions) * 100}%` }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion}
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -50, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="p-8 mb-6 bg-card/80 backdrop-blur border-2">
              <h3 className="text-2xl font-heading font-bold text-foreground mb-8" data-testid="text-question">
                {currentQ.question}
              </h3>

              <div className="space-y-4">
                {currentQ.options.map((option, index) => {
                  const isSelected = selectedAnswer === index;
                  const isCorrect = index === currentQ.correctAnswer;
                  const showCorrect = showResult && isCorrect;
                  const showWrong = showResult && isSelected && !isCorrect;

                  return (
                    <Button
                      key={index}
                      variant="outline"
                      className={`w-full p-6 text-lg justify-start gap-3 transition-all ${
                        showCorrect
                          ? "bg-green-100 dark:bg-green-900/30 border-green-500 border-2"
                          : showWrong
                          ? "bg-red-100 dark:bg-red-900/30 border-red-500 border-2"
                          : isSelected
                          ? "bg-primary/10 border-primary"
                          : ""
                      }`}
                      onClick={() => !showResult && handleAnswer(index)}
                      disabled={showResult}
                      data-testid={`button-option-${index}`}
                    >
                      <div
                        className={`w-8 h-8 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                          showCorrect
                            ? "bg-green-500 border-green-500"
                            : showWrong
                            ? "bg-red-500 border-red-500"
                            : "border-muted-foreground"
                        }`}
                      >
                        {showCorrect ? (
                          <CheckCircle2 className="w-5 h-5 text-white" />
                        ) : showWrong ? (
                          <XCircle className="w-5 h-5 text-white" />
                        ) : (
                          <span className="font-bold text-muted-foreground">
                            {String.fromCharCode(65 + index)}
                          </span>
                        )}
                      </div>
                      <span className={showCorrect || showWrong ? "font-bold" : ""}>
                        {option}
                      </span>
                    </Button>
                  );
                })}
              </div>
            </Card>

            {showResult && (
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="text-center"
              >
                {selectedAnswer === currentQ.correctAnswer ? (
                  <div className="text-2xl font-heading font-bold text-green-600 dark:text-green-400">
                    Excellent! That's correct! 🎉
                  </div>
                ) : (
                  <div className="text-2xl font-heading font-bold text-orange-600 dark:text-orange-400">
                    Not quite! Keep trying! 💪
                  </div>
                )}
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
