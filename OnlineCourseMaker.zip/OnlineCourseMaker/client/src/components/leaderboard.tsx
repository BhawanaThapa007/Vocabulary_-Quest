import { LeaderboardEntry } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Trophy, Star, Medal, Target } from "lucide-react";
import { motion } from "framer-motion";

interface LeaderboardProps {
  data?: LeaderboardEntry[];
}

export default function Leaderboard({ data }: LeaderboardProps) {
  const topStudents = data?.slice(0, 10) || [];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-5 h-5 text-game-yellow fill-game-yellow" />;
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />;
      case 3:
        return <Medal className="w-5 h-5 text-orange-600" />;
      default:
        return <span className="w-5 h-5 flex items-center justify-center font-bold text-muted-foreground">{rank}</span>;
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  };

  const item = {
    hidden: { x: -20, opacity: 0 },
    show: { x: 0, opacity: 1 },
  };

  return (
    <Card className="p-6 bg-card/50 backdrop-blur">
      <h2 className="text-2xl font-heading font-bold text-foreground mb-4 flex items-center gap-2">
        <Target className="w-6 h-6" />
        Leaderboard
      </h2>
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="space-y-3"
      >
        {topStudents.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-lg font-body">No students yet! Be the first to complete a module!</p>
          </div>
        ) : (
          topStudents.map((student, index) => (
            <motion.div
              key={student.id}
              variants={item}
              className={`flex items-center gap-3 p-3 rounded-lg border ${
                index < 3
                  ? "bg-gradient-to-r from-game-coral/10 to-game-yellow/10 border-primary/30"
                  : "bg-card border-card-border"
              } hover-elevate`}
              data-testid={`leaderboard-entry-${student.studentId}`}
            >
              <div className="flex-shrink-0" data-testid={`rank-${index + 1}`}>
                {getRankIcon(index + 1)}
              </div>
              <Avatar className={`w-10 h-10 border-2 ${student.avatarColor}`}>
                <AvatarFallback className="font-bold text-white" style={{ backgroundColor: student.avatarColor }}>
                  {student.studentName.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-heading font-bold text-sm truncate" data-testid={`text-student-name-${student.studentId}`}>
                  {student.studentName}
                </p>
                <p className="text-xs text-muted-foreground" data-testid={`text-completed-sessions-${student.studentId}`}>
                  {student.completedSessions} sessions completed
                </p>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0" data-testid={`text-total-score-${student.studentId}`}>
                <Star className="w-4 h-4 text-game-yellow fill-game-yellow" />
                <span className="font-bold text-foreground">{student.totalScore}</span>
              </div>
            </motion.div>
          ))
        )}
      </motion.div>
    </Card>
  );
}
